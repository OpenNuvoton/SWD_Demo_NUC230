/* CMSIS-DAP Interface Firmware
 * Copyright (c) 2009-2013 ARM Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "..\FlashOS.h"        // FlashOS Structures


#ifdef __cplusplus
  #define   __I     volatile             /*!< Defines 'read only' permissions                 */
#else
  #define   __I     volatile const       /*!< Defines 'read only' permissions                 */
#endif
#define     __O     volatile             /*!< Defines 'write only' permissions                */
#define     __IO    volatile             /*!< Defines 'read / write' permissions              */


typedef struct
{
    __I  uint32_t PDID;          /* Offset: 0x00  Part Device Identification Number Register                         */
    __IO uint32_t RSTSTS;        /* Offset: 0x04  System Reset Status Register                                       */
    __IO uint32_t IPRST0;        /* Offset: 0x08  Peripheral  Reset Control Register 0                               */
    __IO uint32_t IPRST1;        /* Offset: 0x0C  Peripheral Reset Control Register 1                                */
    __IO uint32_t IPRST2;        /* Offset: 0x10  Peripheral Reset Control Register 2                                */
    __I  uint32_t RESERVE0[1];  
    __IO uint32_t BODCTL;        /* Offset: 0x18  Brown-Out Detector Control Register                                */
    __IO uint32_t IVSCTL;        /* Offset: 0x1C  Internal Voltage Source Control Register                           */
    __I  uint32_t RESERVE1[1];  
    __IO uint32_t PORCTL;        /* Offset: 0x24  Power-On-Reset Controller Register                                 */
    __IO uint32_t VREFCTL;       /* Offset: 0x28  VREF Control Register                                              */
    __IO uint32_t USBPHY;        /* Offset: 0x2C  USB PHY Control Register                                           */
    __IO uint32_t GPA_MFPL;      /* Offset: 0x30  GPIOA Low Byte Multiple Function Control Register                  */
    __IO uint32_t GPA_MFPH;      /* Offset: 0x34  GPIOA High Byte Multiple Function Control Register                 */
    __IO uint32_t GPB_MFPL;      /* Offset: 0x38  GPIOB Low Byte Multiple Function Control Register                  */
    __IO uint32_t GPB_MFPH;      /* Offset: 0x3C  GPIOB High Byte Multiple Function Control Register                 */
    __IO uint32_t GPC_MFPL;      /* Offset: 0x40  GPIOC Low Byte Multiple Function Control Register                  */
    __IO uint32_t GPC_MFPH;      /* Offset: 0x44  GPIOC High Byte Multiple Function Control Register                 */
    __IO uint32_t GPD_MFPL;      /* Offset: 0x48  GPIOD Low Byte Multiple Function Control Register                  */
    __IO uint32_t GPD_MFPH;      /* Offset: 0x4C  GPIOD High Byte Multiple Function Control Register                 */
    __IO uint32_t GPE_MFPL;      /* Offset: 0x50  GPIOE Low Byte Multiple Function Control Register                  */
    __IO uint32_t GPE_MFPH;      /* Offset: 0x54  GPIOE High Byte Multiple Function Control Register                 */
    __IO uint32_t GPF_MFPL;      /* Offset: 0x58  GPIOF Low Byte Multiple Function Control Register                  */
    __I  uint32_t RESERVE2[25]; 
    __IO uint32_t SRAM_INTCTL;   /* Offset: 0xC0  System SRAM Interrupt Enable Control Register                      */
    __I  uint32_t SRAM_STATUS;   /* Offset: 0xC4  System SRAM Parity Error Status Register                           */
    __I  uint32_t SRAM_ERRADDR;  /* Offset: 0xC8  System SRAM Parity Check Error Address Register                    */
    __I  uint32_t RESERVE3[1];  
    __IO uint32_t SRAM_BISTCTL;  /* Offset: 0xD0  System SRAM BIST Test Control Register                             */
    __I  uint32_t SRAM_BISTSTS;  /* Offset: 0xD4  System SRAM BIST Test Status Register                              */
    __I  uint32_t RESERVE4[6];  
    __IO uint32_t IRCTCTL;       /* Offset: 0xF0  IRC Trim Control Register                                          */
    __IO uint32_t IRCTIEN;       /* Offset: 0xF4  IRC Trim Interrupt Enable Register                                 */
    __IO uint32_t IRCTISTS;      /* Offset: 0xF8  IRC Trim Interrupt Status Register                                 */
    __I  uint32_t RESERVE5[1];  
    __IO uint32_t REGLCTL;       /* Offset: 0x100  Register Lock Control Register                                    */

} SYS_T;


typedef struct
{
    __IO uint32_t PWRCTL;        /* Offset: 0x00  System Power-down Control Register                                 */
    __IO uint32_t AHBCLK;        /* Offset: 0x04  AHB Devices Clock Enable Control Register                          */
    __IO uint32_t APBCLK0;       /* Offset: 0x08  APB Devices Clock Enable Control Register 0                        */
    __IO uint32_t APBCLK1;       /* Offset: 0x0C  APB Devices Clock Enable Control Register 1                        */
    __IO uint32_t CLKSEL0;       /* Offset: 0x10  Clock Source Select Control Register 0                             */
    __IO uint32_t CLKSEL1;       /* Offset: 0x14  Clock Source Select Control Register 1                             */
    __IO uint32_t CLKSEL2;       /* Offset: 0x18  Clock Source Select Control Register 2                             */
    __IO uint32_t CLKSEL3;       /* Offset: 0x1C  Clock Source Select Control Register 3                             */
    __IO uint32_t CLKDIV0;       /* Offset: 0x20  Clock Divider Number Register 0                                    */
    __IO uint32_t CLKDIV1;       /* Offset: 0x24  Clock Divider Number Register 1                                    */
    __I  uint32_t RESERVE0[6];  
    __IO uint32_t PLLCTL;        /* Offset: 0x40  PLL Control Register                                               */
    __I  uint32_t RESERVE1[3];  
    __I  uint32_t STATUS;        /* Offset: 0x50  Clock Status Monitor Register                                      */
    __I  uint32_t RESERVE2[3];  
    __IO uint32_t CLKOCTL;       /* Offset: 0x60  Clock Output Control Register                                      */
    __I  uint32_t RESERVE3[3];  
    __IO uint32_t CLKDCTL;       /* Offset: 0x70  Clock Fail Detector Control Register                               */
    __IO uint32_t CLKDSTS;       /* Offset: 0x74  Clock Fail Detector Status Register                                */
    __IO uint32_t CDUPB;         /* Offset: 0x78  Clock Frequency Detector Upper Boundary Register                   */
    __IO uint32_t CDLOWB;        /* Offset: 0x7C  Clock Frequency Detector Low Boundary Register                     */

} CLK_T;


typedef struct
{
    __IO uint32_t ISPCTL;        /* Offset: 0x00  ISP Control Register                                               */
    __IO uint32_t ISPADDR;       /* Offset: 0x04  ISP Address Register                                               */
    __IO uint32_t ISPDAT;        /* Offset: 0x08  ISP Data Register                                                  */
    __IO uint32_t ISPCMD;        /* Offset: 0x0C  ISP CMD Register                                                   */
    __IO uint32_t ISPTRG;        /* Offset: 0x10  ISP Trigger Control Register                                       */
    __I  uint32_t DFBA;          /* Offset: 0x14  Data Flash Base Address                                            */
    __IO uint32_t FTCTL;         /* Offset: 0x18  Flash Access Time Control Register                                 */
    __IO uint32_t ICPCTL;        /* Offset: 0x1C  ISP Control Register                                               */
    __I  uint32_t RESERVE0[8];  
    __I  uint32_t ISPSTS;        /* Offset: 0x40  ISP Status Register                                                */
    __I  uint32_t RESERVE1[15]; 
    __IO uint32_t MPDAT0;        /* Offset: 0x80  ISP Data0 Register                                                 */
    __IO uint32_t MPDAT1;        /* Offset: 0x84  ISP Data1 Register                                                 */
    __IO uint32_t MPDAT2;        /* Offset: 0x88  ISP Data2 Register                                                 */
    __IO uint32_t MPDAT3;        /* Offset: 0x8C  ISP Data3 Register                                                 */
    __I  uint32_t RESERVE2[12]; 
    __I  uint32_t MPSTS;         /* Offset: 0xC0  ISP Multi-Program Status Register                                  */
    __I  uint32_t MPADDR;        /* Offset: 0xC4  ISP Multi-Program Address Register                                 */

} FMC_T;


#define SYS_IPRST0_CHIPRST_Pos           (0)                                               /*!< SYS_T::IPRST0: CHIPRST Position           */
#define SYS_IPRST0_CHIPRST_Msk           (0x1ul << SYS_IPRST0_CHIPRST_Pos)                 /*!< SYS_T::IPRST0: CHIPRST Mask               */

#define CLK_PWRCTL_HIRCEN_Pos            (2)                                               /*!< CLK_T::PWRCTL: HIRCEN Position            */
#define CLK_PWRCTL_HIRCEN_Msk            (0x1ul << CLK_PWRCTL_HIRCEN_Pos)                  /*!< CLK_T::PWRCTL: HIRCEN Mask                */

#define CLK_AHBCLK_ISPCKEN_Pos           (2)                                               /*!< CLK_T::AHBCLK: ISPCKEN Position           */
#define CLK_AHBCLK_ISPCKEN_Msk           (0x1ul << CLK_AHBCLK_ISPCKEN_Pos)                 /*!< CLK_T::AHBCLK: ISPCKEN Mask               */

#define CLK_STATUS_HIRCSTB_Pos           (4)                                               /*!< CLK_T::STATUS: HIRCSTB Position           */
#define CLK_STATUS_HIRCSTB_Msk           (0x1ul << CLK_STATUS_HIRCSTB_Pos)                 /*!< CLK_T::STATUS: HIRCSTB Mask               */

#define FMC_ISPCTL_ISPEN_Pos             (0)                                               /*!< FMC_T::ISPCTL: ISPEN Position             */
#define FMC_ISPCTL_ISPEN_Msk             (0x1ul << FMC_ISPCTL_ISPEN_Pos)                   /*!< FMC_T::ISPCTL: ISPEN Mask                 */

#define FMC_ISPCTL_APUEN_Pos             (3)                                               /*!< FMC_T::ISPCTL: APUEN Position             */
#define FMC_ISPCTL_APUEN_Msk             (0x1ul << FMC_ISPCTL_APUEN_Pos)                   /*!< FMC_T::ISPCTL: APUEN Mask                 */

#define FMC_ISPCTL_SPUEN_Pos             (2)                                               /*!< FMC_T::ISPCTL: SPUEN Position             */
#define FMC_ISPCTL_SPUEN_Msk             (0x1ul << FMC_ISPCTL_SPUEN_Pos)                   /*!< FMC_T::ISPCTL: SPUEN Mask                 */

#define FMC_ISPCTL_CFGUEN_Pos            (4)                                               /*!< FMC_T::ISPCTL: CFGUEN Position            */
#define FMC_ISPCTL_CFGUEN_Msk            (0x1ul << FMC_ISPCTL_CFGUEN_Pos)                  /*!< FMC_T::ISPCTL: CFGUEN Mask                */

#define FMC_ISPCTL_LDUEN_Pos             (5)                                               /*!< FMC_T::ISPCTL: LDUEN Position             */
#define FMC_ISPCTL_LDUEN_Msk             (0x1ul << FMC_ISPCTL_LDUEN_Pos)                   /*!< FMC_T::ISPCTL: LDUEN Mask                 */

#define FMC_ISPCTL_ISPFF_Pos             (6)                                               /*!< FMC_T::ISPCTL: ISPFF Position             */
#define FMC_ISPCTL_ISPFF_Msk             (0x1ul << FMC_ISPCTL_ISPFF_Pos)                   /*!< FMC_T::ISPCTL: ISPFF Mask                 */

#define FMC_ISPTRG_ISPGO_Pos             (0)                                               /*!< FMC_T::ISPTRG: ISPGO Position             */
#define FMC_ISPTRG_ISPGO_Msk             (0x1ul << FMC_ISPTRG_ISPGO_Pos)                   /*!< FMC_T::ISPTRG: ISPGO Mask                 */

#define FMC_ICPCLT_ICPEN_Pos             (0)                                               /*!< FMC_T::ICPCTL: ICPEN Position             */
#define FMC_ICPCLT_ICPEN_Msk             (0x1ul << FMC_ICPCLT_ICPEN_Pos)                   /*!< FMC_T::ICPCTL: ICPEN Mask                 */

/* Peripheral memory map */
#define AHBPERIPH_BASE       (0x50000000UL)                              /*!< (Peripheral) Base Address */
#define GCR_BASE             (AHBPERIPH_BASE + 0x00000)
#define CLK_BASE             (AHBPERIPH_BASE + 0x00200)
#define FMC_BASE             (AHBPERIPH_BASE + 0x0C000)

#define SYS                  ((SYS_T *)   GCR_BASE)
#define CLK                  ((CLK_T *)   CLK_BASE)
#define FMC                  ((FMC_T *)   FMC_BASE)

/*---------------------------------------------------------------------------------------------------------*/
/*  ISPCMD constant definitions                                                                            */
/*---------------------------------------------------------------------------------------------------------*/
#define FMC_ISPCMD_READ         0x00     /*!< ISP Command: Read Flash               */
#define FMC_ISPCMD_PROGRAM      0x21     /*!< ISP Command: 32-bit Program Flash     */
#define FMC_ISPCMD_WRITE_8      0x61     /*!< ISP Command: 64-bit program Flash     */
#define FMC_ISPCMD_PAGE_ERASE   0x22     /*!< ISP Command: Page Erase Flash         */
#define FMC_ISPCMD_READ_CID     0x0B     /*!< ISP Command: Read Company ID          */
#define FMC_ISPCMD_READ_UID     0x04     /*!< ISP Command: Read Unique ID           */
#define FMC_ISPCMD_READ_DID     0x0C     /*!< ISP Command: Read Device ID           */
#define FMC_ISPCMD_VECMAP       0x2E     /*!< ISP Command: Set vector mapping       */
#define FMC_ISPCMD_CHECKSUM     0x0D     /*!< ISP Command: Read Checksum            */
#define FMC_ISPCMD_CAL_CHECKSUM 0x2D     /*!< ISP Command: Run Check Calculation    */
#define FMC_ISPCMD_MULTI_PROG   0x27     /*!< ISP Command: Flash Multi-Word Program */



uint32_t Init(uint32_t adr, uint32_t clk, uint32_t fnc)
{
    int delay = 100;

    SYS->REGLCTL = 0x59;
    SYS->REGLCTL = 0x16;
    SYS->REGLCTL = 0x88;
    if (!(SYS->REGLCTL & 0x01))
        return(1);                                          // Not able to unlock 

    CLK->PWRCTL |= CLK_PWRCTL_HIRCEN_Msk;       // Enable HIRC 22MHz 
    CLK->AHBCLK |= CLK_AHBCLK_ISPCKEN_Msk;      // Enable ISP Clock
    while(delay--);

    FMC->ISPCTL |= (FMC_ISPCTL_ISPEN_Msk | FMC_ISPCTL_LDUEN_Msk | FMC_ISPCTL_APUEN_Msk | FMC_ISPCTL_SPUEN_Msk);  // Enable ISP function
    FMC->ICPCTL |= (FMC_ICPCLT_ICPEN_Msk);                         // Enable ICP functions

    if (!(FMC->ISPCTL & FMC_ISPCTL_ISPEN_Msk))
        return (1);                             // ISP not enabled 

    FMC->ISPCTL |= FMC_ISPCTL_ISPFF_Msk;        // Reset Error Flag

    return (0);
}


/*
 *  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

uint32_t UnInit(uint32_t fnc)
{
    while (FMC->ISPTRG & FMC_ISPTRG_ISPGO_Msk); // Wait until command is finished

    SYS->IPRST0 = SYS_IPRST0_CHIPRST_Msk;

    return (0);
}


/*  Blank Check Block in Flash Memory
 *    Parameter:      adr:  Block Start Address
 *                    sz:   Block Size (in bytes)
 *                    pat:  Block Pattern
 *    Return Value:   0 - OK,  1 - Failed
 */

// int BlankCheck (unsigned long adr, unsigned long sz, unsigned char pat)
// {
//     return (flash_verify_erase(&g_flash, adr, sz, kFlashMargin_Normal) != kStatus_Success);
// }
//

// /*
//  *  Verify Flash Contents
//  *    Parameter:      adr:  Start Address
//  *                    sz:   Size (in bytes)
//  *                    buf:  Data
//  *    Return Value:   (adr+sz) - OK, Failed Address
//  */
// unsigned long Verify (unsigned long adr, unsigned long sz, unsigned char *buf)
// {
//     uint32_t failedAddress;
//     status_t status = flash_verify_program(&g_flash, adr, sz,
//                               (const uint8_t *)buf, kFlashMargin_Normal,
//                               &failedAddress, NULL);
//
//     if (status == kStatus_Success)
//     {
//         // Finished without Errors
//         return (adr+sz);
//     }
//     else
//     {
//         return failedAddress;
//     }
// }

/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseChip(void)
{
    return (0);
}


/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseSector(uint32_t adr)
{
    while (FMC->ISPTRG & FMC_ISPTRG_ISPGO_Msk); // Wait until command is finished

    FMC->ISPCTL |= FMC_ISPCTL_ISPFF_Msk;        // Reset Error Flag

    FMC->ISPCMD  = FMC_ISPCMD_PAGE_ERASE;       // Prepare Command
    FMC->ISPADDR = adr;                         // Prepare Address
    FMC->ISPTRG  = FMC_ISPTRG_ISPGO_Msk;        // Execute Command
    __isb(0);

    while (FMC->ISPTRG & FMC_ISPTRG_ISPGO_Msk); // Wait until command is finished

    if (FMC->ISPCTL &  FMC_ISPCTL_ISPFF_Msk)    // Check for Error
    {
        FMC->ISPCTL |= FMC_ISPCTL_ISPFF_Msk;    // Reset Error Flags
        return (1);                             // Failed
    }

    return (0);                                 // Done
}

/*
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t ProgramPage(uint32_t adr, uint32_t sz, uint8_t *buf)
{
    while (FMC->ISPTRG & FMC_ISPTRG_ISPGO_Msk); // Wait until command is finished
  
    FMC->ISPCTL |= FMC_ISPCTL_ISPFF_Msk;        // Reset Error Flag

    FMC->ISPCMD = FMC_ISPCMD_PROGRAM;           // Prepare Command

    while (sz)
    {
        FMC->ISPADDR = adr;                     // Prepare Address
        FMC->ISPDAT	 = *((uint32_t *)buf);      // Prepare Data
        FMC->ISPTRG  = FMC_ISPTRG_ISPGO_Msk;    // Execute Command
        __isb(0);

        while (FMC->ISPTRG & FMC_ISPTRG_ISPGO_Msk); // Wait until command is finished

        if (FMC->ISPCTL &  FMC_ISPCTL_ISPFF_Msk)    // Check for Error
        {
            FMC->ISPCTL |= FMC_ISPCTL_ISPFF_Msk;    // Reset Error Flags
            return (1);                             // Failed
        }

        adr += 4;                                   // Go to next Word
        buf += 4;
        sz  -= 4;
    }

    return (0);                                     // Done
}
